//
//  Employee.swift
//  CRUD-FB
//
//  Created by Germán Santos Jaimes on 11/5/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import Foundation

struct Employee{
    var firstName: String
    var lastName: String
    var salary: Double
}
