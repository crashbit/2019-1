//
//  CoffeeAnnotation.swift
//  hello-maps
//
//  Created by Mohammad Azam on 8/5/18.
//  Copyright © 2018 Mohammad Azam. All rights reserved.
//

import Foundation
import MapKit

class CoffeeAnnotation :MKPointAnnotation {
    
    var imageURL :String! 
}
